public class WhileTest2 {
	public static void main(String args[])
	{
		int x = 3;
		int y = 1;
		while (y <= 9)
		{
			System.out.println(x + " * " + y + " = " + x * y);
			y++;
		}
	}
}