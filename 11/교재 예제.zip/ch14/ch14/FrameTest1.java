import javax.swing.*;
public class FrameTest1{
	public static void main(String[] args) {
		JFrame jf = new JFrame("Test Frame");
		jf.setSize(400,300);
		jf.setVisible(true);
	}
}