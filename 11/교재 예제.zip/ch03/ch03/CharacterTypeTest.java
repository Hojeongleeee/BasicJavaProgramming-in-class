public class CharacterTypeTest {
	public static void main(String args[])
	{
		char ch1 = 'K';
		char ch2 = '\u004f';
		char ch3 = 'R';
		char ch4 = '\u0045';
		char ch5 = 'A';
		char ch6 = '��';
		char ch7 = '��';
		System.out.println("��°�� : " + ch6 + ch7 + "=" + ch1 + ch2 + ch3 + ch4 + ch5);
	}
}