public class TernaryOPTest {
	public static void main(String args[])
	{
		int i=7;
		boolean j;
		System.out.println(i +"�� ¦���Դϱ�?");
		j = (i % 2 == 0) ? true : false;
		System.out.println(j);
	}
}