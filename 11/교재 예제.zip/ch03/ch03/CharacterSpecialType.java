public class CharacterSpecialType {
	public static void main(String args[])
	{
		char ch1 = '\"';
		char ch2 = '��';
		char ch3 = '��';
		char ch4 = '\"';
		char ch5 = '\t';
		char ch6 = '��';
		char ch7 = '��';
		char ch8 = '\n';
		char ch9 = '��';
		char ch10 = '��';
		System.out.println("��°�� :\n" + ch1 + ch2 + ch3 + ch4 + ch5 + ch6 + ch7 + ch8 + ch9 + ch10);
	}
}