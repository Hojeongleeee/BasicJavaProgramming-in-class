public class BitOPTest1 {
	public static void main(String args[])
	{
		int a = 3;
		int b = 5;
		int c = a | b;
		int d = a & b;
		int e = a ^ b;
		System.out.println(" a = " + a);
		System.out.println(" b = " + b);
		System.out.println(" a|b = " + c);
		System.out.println(" a&b = " + d);
		System.out.println(" a^b = " + e);
	}
}