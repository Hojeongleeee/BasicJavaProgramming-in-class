public class LogicErrorTest {
	public static void main(String args[]) {
		int i = 300 ;
		int j = 500 ;
		j += i + j ;
		System.out.println("�հ�� = " + j) ;
	}
}