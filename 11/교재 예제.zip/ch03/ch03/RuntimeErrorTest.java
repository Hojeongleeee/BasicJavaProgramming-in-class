public class RuntimeErrorTest {
	public static void main(String args[]) {
		int i = 3 / 0 ;
		int j = 5 / 0 ;
	}
}