public class ReservedWordTest {
	public static void main(String args[]) {
		int if = 20;
		float for = 30.0;
	}
}